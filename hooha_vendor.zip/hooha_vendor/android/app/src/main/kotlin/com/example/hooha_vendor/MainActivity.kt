package com.example.hooha_vendor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
