
class ConstantsUrls{
  static String commonUrl="https://dv-food-app.herokuapp.com/api/";

  static String Login_USER=commonUrl + "vendor/login";

}