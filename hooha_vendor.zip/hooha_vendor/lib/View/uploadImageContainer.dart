import 'package:flutter/material.dart';

class UploadImageContainer extends StatefulWidget {
  const UploadImageContainer({Key? key}) : super(key: key);

  @override
  _UploadImageContainerState createState() => _UploadImageContainerState();
}

class _UploadImageContainerState extends State<UploadImageContainer> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

