import 'package:flutter/material.dart';

class RequestContainer extends StatefulWidget {
  const RequestContainer({Key? key}) : super(key: key);

  @override
  _RequestContainerState createState() => _RequestContainerState();
}

class _RequestContainerState extends State<RequestContainer> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
