import 'package:flutter/material.dart';

class CustomizationContainer extends StatefulWidget {
  const CustomizationContainer({Key? key}) : super(key: key);

  @override
  _CustomizationContainerState createState() => _CustomizationContainerState();
}

class _CustomizationContainerState extends State<CustomizationContainer> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
