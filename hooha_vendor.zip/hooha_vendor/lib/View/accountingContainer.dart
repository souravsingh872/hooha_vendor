import 'package:flutter/material.dart';

class AccountingContainer extends StatefulWidget {
  const AccountingContainer({Key? key}) : super(key: key);

  @override
  _AccountingContainerState createState() => _AccountingContainerState();
}

class _AccountingContainerState extends State<AccountingContainer> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
